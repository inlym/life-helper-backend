'use strict'

const MYSQL_MAIN_CONFIG = {
	host: 'rm-bp1kpw2840t006d91125010.mysql.rds.aliyuncs.com',
	port: 3306,
	user: 'mp_helper_prod_user',
	password: 'LTxF39BEwLKRkewD',
	database: 'mp_helper_prod_db'
}



const REDIS_MAIN_CONFIG = {
	host: 'r-bp1kfp8i3zk0w7p2w4.redis.rds.aliyuncs.com',
	port: 6379,
	family: 4,
	password: 'rw4FHo4SsMnCsXAqnU9Am8S3xhvYIdYr',
	db: 8
}



/**
 * 阿里云 OSS 配置，详情见阿里云官方文档
 * https://help.aliyun.com/document_detail/64097.html
 * 
 * [ OSS_IMG ] 专门用来存放图片文件
 */
const OSS_IMG_CONFIG = {
	region: 'oss-cn-hangzhou',
	accessKeyId: 'LTAI4G1auPyjbdFvff2Yofga',
	accessKeySecret: 'xHcnArfo0lZJNG0pJp5SPV7e6mI7MR',
	bucket: 'img-inlym-com',
	endpoint: 'oss-cn-hangzhou-internal.aliyuncs.com',
	internal: true,    // 生产环境使用 VPC 内网访问 OSS
}



/**
 * OSS 内文件的访问域名
 *  [ internalUseDomain ] => 内部使用访问域名，用于内部获取 object 使用，用于不需要向用户展示 url 地址的场景
 *  [ customDomain ] => 自定义的访问域名，用于需要向用户展示地址的场景
 */
const OSS_IMG_DOMAINS = {
	internalUseDomain: 'img-inlym-com.oss-cn-hangzhou-internal.aliyuncs.com',
	customDomain: 'img.inlym.com'
}



module.exports = {
	MYSQL_MAIN_CONFIG,
	REDIS_MAIN_CONFIG,
	OSS_IMG_CONFIG,
	OSS_IMG_DOMAINS,
}