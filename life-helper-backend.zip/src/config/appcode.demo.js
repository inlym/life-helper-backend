/**
 *  --------------------------  使用须知  --------------------------
 *    1. 使用时，请将文件名中的 [ .demo ] 去掉，如本文件改名为 [ appcode.js ]
 *    2. 配置文件中的 [ xxxxxxxxxxxxxxxx ] 请替换成你的实际内容
 *    3. 本项目除了代码开源外，相应服务器等资源不共享，请勿向本人索取
 */



'use strict'

module.exports = {
	IP_LOCATION_API_APPCODE:'xxxxxxxxxxxxxxxx',
	WEATHER_API_APPCODE:'xxxxxxxxxxxxxxxx',
}