'use strict'

const DEVELOPMENT_CONFIG = require('./config.development')
const PRODUCTION_CONFIG = require('./config.production')

// 环境：开发环境 => development  生产环境 => production
const STAGE = 'development'


/**
 *  主小程序开发者ID
 * 
 * 获取方式：
 *   1. 访问小程序后台，地址：https://mp.weixin.qq.com
 *   2. 登录后，依次点击：左侧菜单栏的【开发】——顶部标签栏【开发设置】，在第一项的【开发者ID】中的【AppSecret(小程序密钥)】中进行生成或重置即可
 */
const MINIPROGRAM_MAIN_DEVELOPER_ID = {
	appid: 'wx09c0a1ea5251c75a',
	secret: 'be6df5aba878d07a8cb79cf31371108f'
}


let outputConfig = {
	MINIPROGRAM_MAIN_DEVELOPER_ID,
}







if (STAGE === 'production') {
	Object.assign(outputConfig, PRODUCTION_CONFIG)
} else {
	Object.assign(outputConfig, DEVELOPMENT_CONFIG)
}

module.exports = outputConfig