'use strict'


const { uploadImageToOss } = require('../src/lib/oss')
const fs = require('fs')

// const buf = fs.readFileSync('a.jpg')
const buf = Buffer.from('a.png')
uploadImageToOss(buf)
	.then(function (res) {
		console.log('-- ok --')
		console.log(res)
	})
	.catch(function (err) {
		console.log('-- error --')
		console.log(err)
	})