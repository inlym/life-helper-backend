'use strict'


const { createTokenForSpecificUserId, getUserIdByToken } = require('../src/lib/auth')

// createTokenForSpecificUserId(111)
// 	.then(res => {
// 		console.log(res)
// 	})
// 	.catch(err => {
// 		console.log(err)
// 	})

getUserIdByToken('E6K4noHWxSdsfXyMuAZ86mk3Oeb4y1T1CnW')
	.then(res => {
		console.log(res)
	})
	.catch(err => {
		console.log(err)
	})
