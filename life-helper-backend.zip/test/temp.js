'use strict'

const axios = require('axios')

axios('https://api.inlym.com').then(console.log)