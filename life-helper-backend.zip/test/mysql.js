'use strict'

const Mysql = require('mysql')
const { MYSQL_MAIN_CONFIG } = require('../src/config/config.global')

const mysql = Mysql.createConnection(MYSQL_MAIN_CONFIG)
mysql.query('show databases;',function(error, results, fields){
	if(error){
		throw error
	}

	console.log(results)
})