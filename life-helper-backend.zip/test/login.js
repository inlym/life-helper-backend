'use strict'


const { wxLogin } = require('../src/lib/auth.js')

const code = '021CG6zJ1FkYU10mCUzJ11U6zJ1CG6z6'
wxLogin(code)
	.then(res => {
		console.log('--- success ---')
		console.log(res)
	})
	.catch(err => {
		console.log('--- failed ---')
		console.log(err)
	})
