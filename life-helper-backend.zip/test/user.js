'use strict'


const { registerNewWxUser, getUserIdByOpenid } = require('../src/lib/user')

// registerNewWxUser('dfsagsfdgfasdfasdaafsadfsafsdaf')
// 	.then(res => {
// 		console.log(typeof res)
// 	})
// 	.catch(err => {
// 		console.log('-----------------------')
// 		console.log(err)
// 	})

const openid = 'dfsagsfdgfasdfasdfsadfsafsdaf'
getUserIdByOpenid(openid)
	.then(res => {
		console.log(res)
	})
	.catch(err => {
		console.log('-----------------------')
		console.log(err)
	})
