'use strict'

const { code2Session } = require('../src/lib/mp-openid')

const code = '061a77Tn1UlHtn0yUyVn1w9gTn1a77TE'

code2Session(code)
	.then(function (res) {
		console.log('-- ok --')
		console.log(res)
	})
	.catch(function (err) {
		console.log('-- error --')
		console.log(err)
	})