'use strict'

const { generateRandomString } = require('../src/utils/string')

console.log(generateRandomString(16))