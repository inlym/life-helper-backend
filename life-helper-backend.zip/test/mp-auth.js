'use strict'

const mp = require('../src/lib/mp-auth')
mp.getWXAccessToken()
	.then(function (res) {
		console.log('-- success --')
		console.log(res)
	})
	.catch(function (err) {
		console.log(err)
	})