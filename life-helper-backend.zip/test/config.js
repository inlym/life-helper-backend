'use strict'

const config = require('../src/config/config.global')
console.log(config)