'use strict'

const { fetchLocationByIP } = require('../src/ext/ip')
const { fetchWeatherByCoordinate } = require('../src/ext/weather')

const ip = '112.10.67.146'
fetchLocationByIP(ip)
	.then(function (res) {
		console.log(res)
		return fetchWeatherByCoordinate(res.lng,res.lat)
	})
	.then(function (res) {
		console.log(222)
		console.log(res)
	})
	.catch(function (err) {
		console.log(err)
	})