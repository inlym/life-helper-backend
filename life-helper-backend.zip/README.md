# life-helper-backend
「我的个人助手」小程序服务端部分代码。
